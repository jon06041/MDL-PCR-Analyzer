-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: qpcr_analysis
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analysis_sessions`
--

DROP TABLE IF EXISTS `analysis_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analysis_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `upload_timestamp` datetime DEFAULT NULL,
  `total_wells` int NOT NULL,
  `good_curves` int NOT NULL,
  `success_rate` float NOT NULL,
  `cycle_min` int DEFAULT NULL,
  `cycle_max` int DEFAULT NULL,
  `cycle_count` int DEFAULT NULL,
  `pathogen_breakdown` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analysis_sessions`
--

LOCK TABLES `analysis_sessions` WRITE;
/*!40000 ALTER TABLE `analysis_sessions` DISABLE KEYS */;
INSERT INTO `analysis_sessions` VALUES (1,'BATCH_ML_TEST_batch.csv','2025-08-04 13:55:48',4,2,50,1,50,50,'FAM: 50.0%'),(2,'DEBUG_TEST.csv','2025-08-04 13:55:31',1,0,0,1,5,5,'FAM: 0.0%'),(3,'ML_PERSISTENCE_TEST_test.csv','2025-08-04 13:58:37',2,1,50,1,50,50,'FAM: 50.0%'),(4,'MULTICHANNEL_ML_TEST_multichannel.csv','2025-08-04 14:06:37',6,4,66.6667,1,50,50,'Cy5: 100.0% | FAM: 50.0% | HEX: 100.0% | TexasRed: 0.0%'),(5,'MULTICHANNEL_FEEDBACK_TEST_feedback.csv','2025-08-04 14:09:27',4,3,75,1,50,50,'Cy5: 100.0% | FAM: 100.0% | HEX: 100.0% | TexasRed: 0.0%');
/*!40000 ALTER TABLE `analysis_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_completion_status`
--

DROP TABLE IF EXISTS `channel_completion_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channel_completion_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `experiment_pattern` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fluorophore` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pathogen_target` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` int DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `total_wells` int DEFAULT NULL,
  `good_curves` int DEFAULT NULL,
  `success_rate` float DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `json_data_validated` tinyint(1) DEFAULT NULL,
  `threshold_data_ready` tinyint(1) DEFAULT NULL,
  `control_grid_data_ready` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `channel_completion_status_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `analysis_sessions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_completion_status`
--

LOCK TABLES `channel_completion_status` WRITE;
/*!40000 ALTER TABLE `channel_completion_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_completion_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experiment_statistics`
--

DROP TABLE IF EXISTS `experiment_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `experiment_statistics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `experiment_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `analysis_timestamp` datetime DEFAULT NULL,
  `fluorophore_stats` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_experiment_statistics_experiment_name` (`experiment_name`),
  KEY `ix_experiment_statistics_test_name` (`test_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experiment_statistics`
--

LOCK TABLES `experiment_statistics` WRITE;
/*!40000 ALTER TABLE `experiment_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `experiment_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `well_results`
--

DROP TABLE IF EXISTS `well_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `well_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int NOT NULL,
  `well_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fluorophore` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_good_scurve` tinyint(1) NOT NULL,
  `r2_score` float DEFAULT NULL,
  `rmse` float DEFAULT NULL,
  `amplitude` float DEFAULT NULL,
  `steepness` float DEFAULT NULL,
  `midpoint` float DEFAULT NULL,
  `baseline` float DEFAULT NULL,
  `data_points` int DEFAULT NULL,
  `cycle_range` float DEFAULT NULL,
  `fit_parameters` text COLLATE utf8mb4_unicode_ci,
  `parameter_errors` text COLLATE utf8mb4_unicode_ci,
  `fitted_curve` text COLLATE utf8mb4_unicode_ci,
  `anomalies` text COLLATE utf8mb4_unicode_ci,
  `raw_cycles` text COLLATE utf8mb4_unicode_ci,
  `raw_rfu` text COLLATE utf8mb4_unicode_ci,
  `cq_value` float DEFAULT NULL,
  `sample_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thresholds` text COLLATE utf8mb4_unicode_ci,
  `threshold_value` float DEFAULT NULL,
  `curve_classification` text COLLATE utf8mb4_unicode_ci,
  `cqj` text COLLATE utf8mb4_unicode_ci,
  `calcj` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `well_results_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `analysis_sessions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `well_results`
--

LOCK TABLES `well_results` WRITE;
/*!40000 ALTER TABLE `well_results` DISABLE KEYS */;
INSERT INTO `well_results` VALUES (1,2,'A1_FAM','FAM',0,0.95,NULL,500,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5]','[50, 60, 100, 200, 500]',25,'Test_Sample',NULL,NULL,'{\"class\": \"N/A\"}',NULL,NULL),(2,1,'A1_FAM','FAM',0,0.9967,NULL,7012.8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[50.2, 51.1, 50.8, 52.3, 51.7, 53.0, 54.2, 55.8, 57.1, 59.2, 62.1, 65.8, 70.3, 76.2, 83.7, 93.1, 105.8, 122.3, 143.2, 169.8, 202.7, 243.1, 292.8, 352.1, 422.3, 504.7, 599.2, 706.8, 827.1, 960.3, 1106.7, 1266.2, 1439.1, 1625.8, 1826.7, 2042.3, 2273.1, 2519.7, 2782.8, 3063.1, 3361.2, 3678.1, 4014.7, 4372.3, 4751.2, 5152.8, 5578.1, 6028.7, 6506.2, 7012.8]',24.7,'Sample_001_H1',NULL,NULL,'{\"class\": \"SUSPICIOUS\", \"confidence\": 1.0, \"method\": \"Rule-based\", \"pathogen\": \"NGON\", \"ml_prediction\": \"SUSPICIOUS\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T13:55:48.378943\", \"original_classification\": \"N/A\", \"training_samples\": 51}',NULL,NULL),(3,1,'A2_FAM','FAM',0,0.9967,NULL,2008.8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[49.1, 49.8, 50.2, 50.5, 51.1, 52.3, 53.7, 55.8, 58.2, 61.1, 64.8, 69.2, 74.5, 80.8, 88.3, 97.2, 108.1, 121.3, 136.8, 155.2, 176.8, 201.9, 230.7, 263.4, 300.8, 343.2, 391.7, 446.8, 509.2, 580.1, 660.3, 751.2, 853.8, 969.7, 1099.3, 1244.2, 1405.8, 1585.7, 1786.2, 2008.8]',28.3,'Sample_002_H3',NULL,NULL,'{\"class\": \"SUSPICIOUS\", \"confidence\": 1.0, \"method\": \"Rule-based\", \"pathogen\": \"NGON\", \"ml_prediction\": \"SUSPICIOUS\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T13:55:48.388107\", \"original_classification\": \"N/A\", \"training_samples\": 51}',NULL,NULL),(4,1,'A3_FAM','FAM',0,0.9967,NULL,314.2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[48.7, 49.1, 48.9, 49.3, 48.6, 49.8, 48.4, 49.7, 48.8, 49.2, 48.5, 49.6, 48.3, 49.4, 48.9, 50.1, 50.7, 51.5, 52.8, 54.3, 56.2, 58.7, 61.8, 65.4, 69.8, 75.1, 81.2, 88.3, 96.7, 106.2, 117.1, 129.8, 144.2, 160.7, 179.3, 200.4, 224.1, 250.8, 280.7, 314.2]',34.1,'Sample_003_WEAK',NULL,NULL,'{\"class\": \"SUSPICIOUS\", \"confidence\": 1.0, \"method\": \"Rule-based\", \"pathogen\": \"NGON\", \"ml_prediction\": \"SUSPICIOUS\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T13:55:48.399015\", \"original_classification\": \"N/A\", \"training_samples\": 51}',NULL,NULL),(5,1,'B1_FAM','FAM',0,0.1234,NULL,1.2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[48.7, 49.1, 48.9, 49.3, 48.6, 49.8, 48.4, 49.7, 48.8, 49.2, 48.5, 49.6, 48.3, 49.4, 48.9, 49.1, 48.7, 49.5, 48.2, 49.8, 48.6, 49.3, 48.4, 49.7, 48.8, 49.2, 48.5, 49.6, 48.3, 49.4, 48.9, 49.1, 48.7, 49.5, 48.2, 49.8, 48.6, 49.3, 48.4, 49.7, 48.8, 49.2, 48.5, 49.6, 48.3, 49.4, 48.9, 49.1, 48.7, 49.5]',NULL,'NTC_001',NULL,NULL,'{\"class\": \"NEGATIVE\", \"confidence\": 0.5, \"method\": \"Rule-based\", \"pathogen\": \"NGON\", \"ml_prediction\": \"NEGATIVE\", \"ml_confidence\": 0.5, \"ml_timestamp\": \"2025-08-04T13:55:48.412413\", \"original_classification\": \"N/A\", \"training_samples\": 51}',NULL,NULL),(8,3,'A1_FAM','FAM',0,0.9967,NULL,7012.8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[50.2, 51.1, 50.8, 52.3, 51.7, 53.0, 54.2, 55.8, 57.1, 59.2, 62.1, 65.8, 70.3, 76.2, 83.7, 93.1, 105.8, 122.3, 143.2, 169.8, 202.7, 243.1, 292.8, 352.1, 422.3, 504.7, 599.2, 706.8, 827.1, 960.3, 1106.7, 1266.2, 1439.1, 1625.8, 1826.7, 2042.3, 2273.1, 2519.7, 2782.8, 3063.1, 3361.2, 3678.1, 4014.7, 4372.3, 4751.2, 5152.8, 5578.1, 6028.7, 6506.2, 7012.8]',24.7,'Positive_Control_H1',NULL,NULL,'{\"class\": \"WEAK_POSITIVE\", \"confidence\": 1.0, \"method\": \"Expert Review\", \"pathogen\": \"NGON\", \"ml_prediction\": \"SUSPICIOUS\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T13:58:37.490294\", \"original_classification\": \"SUSPICIOUS\", \"training_samples\": 52, \"expert_classification\": \"WEAK_POSITIVE\", \"expert_review_method\": \"ml_feedback_interface\", \"expert_review_timestamp\": \"2025-08-04T13:58:37.522050\"}',NULL,NULL),(9,3,'B1_FAM','FAM',0,0.1234,NULL,1.2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[48.7, 49.1, 48.9, 49.3, 48.6, 49.8, 48.4, 49.7, 48.8, 49.2, 48.5, 49.6, 48.3, 49.4, 48.9, 49.1, 48.7, 49.5, 48.2, 49.8, 48.6, 49.3, 48.4, 49.7, 48.8, 49.2, 48.5, 49.6, 48.3, 49.4, 48.9, 49.1, 48.7, 49.5, 48.2, 49.8, 48.6, 49.3, 48.4, 49.7, 48.8, 49.2, 48.5, 49.6, 48.3, 49.4, 48.9, 49.1, 48.7, 49.5]',NULL,'Negative_Control_NTC',NULL,NULL,'{\"class\": \"NEGATIVE\", \"confidence\": 0.5, \"method\": \"Rule-based\", \"pathogen\": \"NGON\", \"ml_prediction\": \"NEGATIVE\", \"ml_confidence\": 0.5, \"ml_timestamp\": \"2025-08-04T13:58:37.501441\", \"original_classification\": \"N/A\", \"training_samples\": 52}',NULL,NULL),(10,4,'A1_FAM','FAM',0,0.9967,NULL,6962.6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[50.2, 51.1, 50.8, 52.3, 51.7, 53.0, 54.2, 55.8, 57.1, 59.2, 62.1, 65.8, 70.3, 76.2, 83.7, 93.1, 105.8, 122.3, 143.2, 169.8, 202.7, 243.1, 292.8, 352.1, 422.3, 504.7, 599.2, 706.8, 827.1, 960.3, 1106.7, 1266.2, 1439.1, 1625.8, 1826.7, 2042.3, 2273.1, 2519.7, 2782.8, 3063.1, 3361.2, 3678.1, 4014.7, 4372.3, 4751.2, 5152.8, 5578.1, 6028.7, 6506.2, 7012.8]',24.7,'Sample_001_H1',NULL,NULL,'{\"class\": \"STRONG_POSITIVE\", \"confidence\": 1.0, \"method\": \"Rule-based\", \"pathogen\": \"H1\", \"ml_prediction\": \"STRONG_POSITIVE\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T14:06:36.641544\", \"original_classification\": \"N/A\", \"training_samples\": 52}',NULL,NULL),(11,4,'A1_HEX','HEX',0,0.9967,NULL,5762.2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[48.1, 48.8, 49.2, 49.5, 50.1, 51.3, 52.7, 54.8, 57.2, 60.1, 63.8, 68.2, 73.5, 79.8, 87.3, 96.2, 107.1, 120.3, 135.8, 154.2, 175.8, 200.9, 229.7, 262.4, 299.8, 342.2, 390.7, 445.8, 508.2, 579.1, 659.3, 750.2, 852.8, 968.7, 1098.3, 1243.2, 1404.8, 1584.7, 1785.2, 2007.8, 2253.1, 2522.7, 2818.3, 3142.1, 3496.8, 3884.2, 4306.7, 4766.8, 5267.2, 5810.3]',28.3,'Sample_001_H3',NULL,NULL,'{\"class\": \"STRONG_POSITIVE\", \"confidence\": 1.0, \"method\": \"Rule-based\", \"pathogen\": \"H3\", \"ml_prediction\": \"STRONG_POSITIVE\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T14:06:36.681449\", \"original_classification\": \"N/A\", \"training_samples\": 52}',NULL,NULL),(12,4,'A1_Cy5','Cy5',0,0.9967,NULL,896.4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[47.7, 48.1, 47.9, 48.3, 47.6, 48.8, 47.4, 48.7, 47.8, 48.2, 47.5, 48.6, 47.3, 48.4, 47.9, 49.1, 49.7, 50.5, 51.8, 53.3, 55.2, 57.7, 60.8, 64.4, 68.8, 74.1, 80.2, 87.3, 95.7, 105.2, 116.1, 128.8, 143.2, 159.7, 178.3, 199.4, 223.1, 249.8, 279.7, 313.2, 350.8, 392.7, 439.3, 491.2, 548.8, 612.7, 683.4, 761.8, 848.2, 943.7]',34.1,'Sample_001_FluB',NULL,NULL,'{\"class\": \"STRONG_POSITIVE\", \"confidence\": 1.0, \"method\": \"Rule-based\", \"pathogen\": \"FLUB\", \"ml_prediction\": \"STRONG_POSITIVE\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T14:06:36.704162\", \"original_classification\": \"N/A\", \"training_samples\": 52}',NULL,NULL),(13,4,'A1_TexasRed','Texas Red',0,0.1234,NULL,1.6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[46.7, 47.1, 46.9, 47.3, 46.6, 47.8, 46.4, 47.7, 46.8, 47.2, 46.5, 47.6, 46.3, 47.4, 46.9, 47.1, 46.7, 47.5, 46.2, 47.8, 46.6, 47.3, 46.4, 47.7, 46.8, 47.2, 46.5, 47.6, 46.3, 47.4, 46.9, 47.1, 46.7, 47.5, 46.2, 47.8, 46.6, 47.3, 46.4, 47.7, 46.8, 47.2, 46.5, 47.6, 46.3, 47.4, 46.9, 47.1, 46.7, 47.5]',NULL,'Sample_001_RSV',NULL,NULL,'{\"class\": \"NEGATIVE\", \"confidence\": 0.5, \"method\": \"Rule-based\", \"pathogen\": \"RSV\", \"ml_prediction\": \"NEGATIVE\", \"ml_confidence\": 0.5, \"ml_timestamp\": \"2025-08-04T14:06:36.714134\", \"original_classification\": \"N/A\", \"training_samples\": 52}',NULL,NULL),(14,4,'B1_FAM','FAM',0,0.1234,NULL,1.6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[49.2, 49.6, 49.4, 49.8, 49.1, 50.3, 49.0, 50.2, 49.3, 49.7, 49.0, 50.1, 48.8, 49.9, 49.4, 49.6, 49.2, 50.0, 48.7, 50.3, 49.1, 49.8, 48.9, 50.2, 49.3, 49.7, 49.0, 50.1, 48.8, 49.9, 49.4, 49.6, 49.2, 50.0, 48.7, 50.3, 49.1, 49.8, 48.9, 50.2, 49.3, 49.7, 49.0, 50.1, 48.8, 49.9, 49.4, 49.6, 49.2, 50.0]',NULL,'Sample_002_H1',NULL,NULL,'{\"class\": \"NEGATIVE\", \"confidence\": 0.5, \"method\": \"Rule-based\", \"pathogen\": \"H1\", \"ml_prediction\": \"NEGATIVE\", \"ml_confidence\": 0.5, \"ml_timestamp\": \"2025-08-04T14:06:36.723980\", \"original_classification\": \"N/A\", \"training_samples\": 52}',NULL,NULL),(15,4,'B1_HEX','HEX',0,0.9967,NULL,23738.3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[48.5, 49.2, 48.9, 49.6, 49.1, 50.4, 51.8, 53.9, 56.7, 60.3, 64.8, 70.5, 77.8, 86.9, 98.3, 112.7, 130.8, 153.2, 180.7, 214.2, 254.8, 303.7, 362.3, 432.1, 515.8, 615.2, 732.8, 872.3, 1037.1, 1230.8, 1458.2, 1723.7, 2032.8, 2391.2, 2805.7, 3283.2, 3831.8, 4460.7, 5180.2, 6001.8, 6938.7, 8005.2, 9217.8, 10595.2, 12159.7, 13936.2, 15952.8, 18241.7, 20839.2, 23786.8]',24.7,'Sample_002_H3',NULL,NULL,'{\"class\": \"STRONG_POSITIVE\", \"confidence\": 1.0, \"method\": \"Rule-based\", \"pathogen\": \"H3\", \"ml_prediction\": \"STRONG_POSITIVE\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T14:06:36.747869\", \"original_classification\": \"N/A\", \"training_samples\": 52}',NULL,NULL),(16,5,'A1_FAM','FAM',0,0.9967,NULL,6962.6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[50.2, 51.1, 50.8, 52.3, 51.7, 53.0, 54.2, 55.8, 57.1, 59.2, 62.1, 65.8, 70.3, 76.2, 83.7, 93.1, 105.8, 122.3, 143.2, 169.8, 202.7, 243.1, 292.8, 352.1, 422.3, 504.7, 599.2, 706.8, 827.1, 960.3, 1106.7, 1266.2, 1439.1, 1625.8, 1826.7, 2042.3, 2273.1, 2519.7, 2782.8, 3063.1, 3361.2, 3678.1, 4014.7, 4372.3, 4751.2, 5152.8, 5578.1, 6028.7, 6506.2, 7012.8]',24.7,'Sample_001_H1',NULL,NULL,'{\"class\": \"POSITIVE\", \"confidence\": 1.0, \"method\": \"Expert Review\", \"pathogen\": \"H1\", \"ml_prediction\": \"STRONG_POSITIVE\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T14:09:27.093408\", \"original_classification\": \"STRONG_POSITIVE\", \"training_samples\": 52, \"expert_classification\": \"POSITIVE\", \"expert_review_method\": \"ml_feedback_interface\", \"expert_review_timestamp\": \"2025-08-04T14:09:27.125103\"}',NULL,NULL),(17,5,'A1_HEX','HEX',0,0.9967,NULL,5762.2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[48.1, 48.8, 49.2, 49.5, 50.1, 51.3, 52.7, 54.8, 57.2, 60.1, 63.8, 68.2, 73.5, 79.8, 87.3, 96.2, 107.1, 120.3, 135.8, 154.2, 175.8, 200.9, 229.7, 262.4, 299.8, 342.2, 390.7, 445.8, 508.2, 579.1, 659.3, 750.2, 852.8, 968.7, 1098.3, 1243.2, 1404.8, 1584.7, 1785.2, 2007.8, 2253.1, 2522.7, 2818.3, 3142.1, 3496.8, 3884.2, 4306.7, 4766.8, 5267.2, 5810.3]',24.7,'Sample_001_H3',NULL,NULL,'{\"class\": \"WEAK_POSITIVE\", \"confidence\": 1.0, \"method\": \"Expert Review\", \"pathogen\": \"H3\", \"ml_prediction\": \"STRONG_POSITIVE\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T14:09:27.149991\", \"original_classification\": \"STRONG_POSITIVE\", \"training_samples\": 53, \"expert_classification\": \"WEAK_POSITIVE\", \"expert_review_method\": \"ml_feedback_interface\", \"expert_review_timestamp\": \"2025-08-04T14:09:27.184688\"}',NULL,NULL),(18,5,'A1_Cy5','Cy5',0,0.9967,NULL,896.4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[47.7, 48.1, 47.9, 48.3, 47.6, 48.8, 47.4, 48.7, 47.8, 48.2, 47.5, 48.6, 47.3, 48.4, 47.9, 49.1, 49.7, 50.5, 51.8, 53.3, 55.2, 57.7, 60.8, 64.4, 68.8, 74.1, 80.2, 87.3, 95.7, 105.2, 116.1, 128.8, 143.2, 159.7, 178.3, 199.4, 223.1, 249.8, 279.7, 313.2, 350.8, 392.7, 439.3, 491.2, 548.8, 612.7, 683.4, 761.8, 848.2, 943.7]',24.7,'Sample_001_FluB',NULL,NULL,'{\"class\": \"NEGATIVE\", \"confidence\": 1.0, \"method\": \"Expert Review\", \"pathogen\": \"FLUB\", \"ml_prediction\": \"STRONG_POSITIVE\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T14:09:27.211118\", \"original_classification\": \"STRONG_POSITIVE\", \"training_samples\": 54, \"expert_classification\": \"NEGATIVE\", \"expert_review_method\": \"ml_feedback_interface\", \"expert_review_timestamp\": \"2025-08-04T14:09:27.256956\"}',NULL,NULL),(19,5,'A1_TexasRed','Texas Red',0,0.9967,NULL,1.6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]','[46.7, 47.1, 46.9, 47.3, 46.6, 47.8, 46.4, 47.7, 46.8, 47.2, 46.5, 47.6, 46.3, 47.4, 46.9, 47.1, 46.7, 47.5, 46.2, 47.8, 46.6, 47.3, 46.4, 47.7, 46.8, 47.2, 46.5, 47.6, 46.3, 47.4, 46.9, 47.1, 46.7, 47.5, 46.2, 47.8, 46.6, 47.3, 46.4, 47.7, 46.8, 47.2, 46.5, 47.6, 46.3, 47.4, 46.9, 47.1, 46.7, 47.5]',24.7,'Sample_001_RSV',NULL,NULL,'{\"class\": \"SUSPICIOUS\", \"confidence\": 1.0, \"method\": \"Expert Review\", \"pathogen\": \"RSV\", \"ml_prediction\": \"STRONG_POSITIVE\", \"ml_confidence\": 1.0, \"ml_timestamp\": \"2025-08-04T14:09:27.266483\", \"original_classification\": \"STRONG_POSITIVE\", \"training_samples\": 55, \"expert_classification\": \"SUSPICIOUS\", \"expert_review_method\": \"ml_feedback_interface\", \"expert_review_timestamp\": \"2025-08-04T14:09:27.299187\"}',NULL,NULL);
/*!40000 ALTER TABLE `well_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'qpcr_analysis'
--

--
-- Dumping routines for database 'qpcr_analysis'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-04 14:14:37
