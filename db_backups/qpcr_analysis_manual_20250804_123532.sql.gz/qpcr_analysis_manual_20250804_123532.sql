-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: qpcr_analysis
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analysis_sessions`
--

DROP TABLE IF EXISTS `analysis_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analysis_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `upload_timestamp` datetime DEFAULT NULL,
  `total_wells` int NOT NULL,
  `good_curves` int NOT NULL,
  `success_rate` float NOT NULL,
  `cycle_min` int DEFAULT NULL,
  `cycle_max` int DEFAULT NULL,
  `cycle_count` int DEFAULT NULL,
  `pathogen_breakdown` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analysis_sessions`
--

LOCK TABLES `analysis_sessions` WRITE;
/*!40000 ALTER TABLE `analysis_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `analysis_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_completion_status`
--

DROP TABLE IF EXISTS `channel_completion_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channel_completion_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `experiment_pattern` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fluorophore` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pathogen_target` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` int DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `total_wells` int DEFAULT NULL,
  `good_curves` int DEFAULT NULL,
  `success_rate` float DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `json_data_validated` tinyint(1) DEFAULT NULL,
  `threshold_data_ready` tinyint(1) DEFAULT NULL,
  `control_grid_data_ready` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `channel_completion_status_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `analysis_sessions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_completion_status`
--

LOCK TABLES `channel_completion_status` WRITE;
/*!40000 ALTER TABLE `channel_completion_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_completion_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experiment_statistics`
--

DROP TABLE IF EXISTS `experiment_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `experiment_statistics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `experiment_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `analysis_timestamp` datetime DEFAULT NULL,
  `fluorophore_stats` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_experiment_statistics_experiment_name` (`experiment_name`),
  KEY `ix_experiment_statistics_test_name` (`test_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experiment_statistics`
--

LOCK TABLES `experiment_statistics` WRITE;
/*!40000 ALTER TABLE `experiment_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `experiment_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `well_results`
--

DROP TABLE IF EXISTS `well_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `well_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int NOT NULL,
  `well_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fluorophore` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_good_scurve` tinyint(1) NOT NULL,
  `r2_score` float DEFAULT NULL,
  `rmse` float DEFAULT NULL,
  `amplitude` float DEFAULT NULL,
  `steepness` float DEFAULT NULL,
  `midpoint` float DEFAULT NULL,
  `baseline` float DEFAULT NULL,
  `data_points` int DEFAULT NULL,
  `cycle_range` float DEFAULT NULL,
  `fit_parameters` text COLLATE utf8mb4_unicode_ci,
  `parameter_errors` text COLLATE utf8mb4_unicode_ci,
  `fitted_curve` text COLLATE utf8mb4_unicode_ci,
  `anomalies` text COLLATE utf8mb4_unicode_ci,
  `raw_cycles` text COLLATE utf8mb4_unicode_ci,
  `raw_rfu` text COLLATE utf8mb4_unicode_ci,
  `cq_value` float DEFAULT NULL,
  `sample_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thresholds` text COLLATE utf8mb4_unicode_ci,
  `threshold_value` float DEFAULT NULL,
  `curve_classification` text COLLATE utf8mb4_unicode_ci,
  `cqj` text COLLATE utf8mb4_unicode_ci,
  `calcj` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `well_results_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `analysis_sessions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `well_results`
--

LOCK TABLES `well_results` WRITE;
/*!40000 ALTER TABLE `well_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `well_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'qpcr_analysis'
--

--
-- Dumping routines for database 'qpcr_analysis'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-04 12:35:32
